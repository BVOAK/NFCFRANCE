<?php

if (! defined( 'ABSPATH')) {
    exit; // Exit if accessed directly
}
// routes /wp-json/gtmi_vcard/v1/statistics
require_once plugin_dir_path( __FILE__) . 'add.php';
require_once plugin_dir_path( __FILE__) . 'find.php';
