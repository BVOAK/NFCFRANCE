<?php


if (! defined( 'ABSPATH')) {
    exit; // Exit if accessed directly
}
// routes /wp-json/gtmi_vcard/v1/vcard
require_once plugin_dir_path( __FILE__) . 'update.php';